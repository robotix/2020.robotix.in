Open the project file and compile with Visual Studio. The project uses the latest technologies. When the program launches, open a map file from the Maps folder.

Sam Allen
http://dotnetperls.com/
