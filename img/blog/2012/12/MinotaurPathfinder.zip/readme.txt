Welcome to the Pathfinder application

-----How to use the application ?

1. Click on the exe file to start the programme
2. Click open map to load the map .txt file

-----How to make a map?
1. Open any map .txt file in the contents of the zip folder
2. W stands for an obstacle. A space stands for empty square on the grid.
'H' stands for the starting position and 'M' stands for the ending position
3. Note that the software is designed to work for 8x8 grids only. So ensure that
the total number of characters in a row is 8 (including the spaces) and the number
of rows are in total 8.

-----How to edit the source code?

***Coming soon***

Brought to you by :-
Technology Robotix Society
www.robotix.in